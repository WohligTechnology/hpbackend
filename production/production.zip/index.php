<!DOCTYPE html><html lang=en ng-app=firstapp><head ng-controller=HeaderCtrl><meta charset=utf-8><meta http-equiv=X-UA-Compatible content="IE=edge"><meta http-equiv=Content-Type content="text/html; charset=utf-8"><meta name=viewport content="width=device-width, initial-scale=1.0"><meta name=description><meta name=author><title ng-bind="'HP - '+template.title">HP</title><link rel="shortcut icon" href=img/favicon.ico><link rel=stylesheet type=text/css href=w/w.css><script src=w/w.js></script><script>
      var isproduction=false;
    </script><!--[if IE]>
 <script src="https://cdn.jsdelivr.net/html5shiv/3.7.2/html5shiv.min.js"></script>
 <script src="https://cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
 <![endif]--></head><body><div class=repeated-item ui-view=""></div></body></html>